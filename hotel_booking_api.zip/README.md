# Hotel Booking Platform - Backend API

## Features
- User registration and login
- JWT authentication
- Hotel room CRUD operations
- Search rooms
- Room booking

## Setup
```bash
pip install -r requirements.txt
python app.py
```