from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///hotel.db'
app.config['JWT_SECRET_KEY'] = 'secret'
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
jwt = JWTManager(app)

# Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

class Room(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    title = db.Column(db.String(100))
    description = db.Column(db.String(300))
    price = db.Column(db.Float)

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    room_id = db.Column(db.Integer, db.ForeignKey('room.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    check_in = db.Column(db.Date)
    check_out = db.Column(db.Date)

# Routes
@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    hashed_pw = bcrypt.generate_password_hash(data['password']).decode('utf-8')
    user = User(username=data['username'], password=hashed_pw)
    db.session.add(user)
    db.session.commit()
    return jsonify({"msg": "User registered"})

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    user = User.query.filter_by(username=data['username']).first()
    if user and bcrypt.check_password_hash(user.password, data['password']):
        token = create_access_token(identity=user.id)
        return jsonify(access_token=token)
    return jsonify({"msg": "Bad credentials"}), 401

@app.route('/rooms', methods=['POST'])
@jwt_required()
def create_room():
    data = request.get_json()
    user_id = get_jwt_identity()
    room = Room(owner_id=user_id, title=data['title'], description=data['description'], price=data['price'])
    db.session.add(room)
    db.session.commit()
    return jsonify({"msg": "Room created"})

@app.route('/rooms/search', methods=['GET'])
def search_rooms():
    rooms = Room.query.all()
    return jsonify([{"id": r.id, "title": r.title, "price": r.price} for r in rooms])

@app.route('/book', methods=['POST'])
@jwt_required()
def book_room():
    data = request.get_json()
    booking = Booking(
        room_id=data['room_id'],
        user_id=get_jwt_identity(),
        check_in=datetime.strptime(data['check_in'], '%Y-%m-%d'),
        check_out=datetime.strptime(data['check_out'], '%Y-%m-%d')
    )
    db.session.add(booking)
    db.session.commit()
    return jsonify({"msg": "Room booked"})

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)